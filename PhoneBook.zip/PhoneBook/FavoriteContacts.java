package PhoneBook;

import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class FavoriteContacts extends JFrame implements ActionListener
{
    JLabel l1;
    JButton bt1,bt2;
    JTable table;
    JScrollPane sp;
    JPanel p1,p2;
    Font f,f1;

    FavoriteContacts()
    {
        super("Favorite Contacts");

        setLocation(250,100);
        setSize(950,550);

        f=new Font("Arial",Font.BOLD,25);
        f1=new Font("Arial",Font.BOLD,15);

        l1=new JLabel("★ Favorite Contacts",JLabel.CENTER);
        l1.setFont(f);

        p1=new JPanel(new BorderLayout());
        p1.add(l1,BorderLayout.CENTER);

        table=new JTable();
        table.setFont(new Font("Arial",Font.PLAIN,14));
        table.setRowHeight(25);

        sp=new JScrollPane(table);

        bt1=new JButton("Refresh");
        bt2=new JButton("Back");

        bt1.setFont(f1);
        bt2.setFont(f1);

        bt1.addActionListener(this);
        bt2.addActionListener(this);

        p2=new JPanel();
        p2.add(bt1);
        p2.add(bt2);

        add(p1,BorderLayout.NORTH);
        add(sp,BorderLayout.CENTER);
        add(p2,BorderLayout.SOUTH);

        showFavorites();

        setVisible(true);
    }

    public void showFavorites()
    {
        try
        {
            ConnectionClass obj=new ConnectionClass();

            String q="select * from add_contact where favorite='YES'";

            ResultSet rs=obj.stm.executeQuery(q);

            DefaultTableModel model=new DefaultTableModel();

            model.addColumn("Name");
            model.addColumn("Nick Name");
            model.addColumn("Phone");
            model.addColumn("Mobile");
            model.addColumn("Email");
            model.addColumn("Address");
            model.addColumn("Company");
            model.addColumn("Position");
            model.addColumn("Group");

            while(rs.next())
            {
                model.addRow(new Object[]
                {
                    rs.getString("name"),
                    rs.getString("nickname"),
                    rs.getString("phone"),
                    rs.getString("mobile"),
                    rs.getString("email"),
                    rs.getString("address"),
                    rs.getString("company"),
                    rs.getString("position"),
                    rs.getString("group_name")
                });
            }

            table.setModel(model);
        }
        catch(Exception ex)
        {
            ex.printStackTrace();

            JOptionPane.showMessageDialog(this,
                    "Error loading favorite contacts.");
        }
    }

    public void actionPerformed(ActionEvent e)
    {
        if(e.getSource()==bt1)
        {
            showFavorites();
        }

        if(e.getSource()==bt2)
        {
            this.setVisible(false);
            new Home().setVisible(true);
        }
    }

    public static void main(String[] args)
    {
        new FavoriteContacts();
    }
}
