package PhoneBook;

import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class TrashContacts extends JFrame implements ActionListener
{
    JLabel title;

    JButton restore;
    JButton permanentDelete;
    JButton emptyTrash;
    JButton refresh;
    JButton back;

    JTable table;
    JScrollPane sp;

    JPanel header;
    JPanel bottom;

    Font titleFont;
    Font buttonFont;

    TrashContacts()
    {
        super("Recently Deleted");

        setSize(1200,600);
        setLocationRelativeTo(null);

        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        setLayout(new BorderLayout(10,10));

        titleFont = new Font(
            "Arial",
            Font.BOLD,
            26
        );

        buttonFont = new Font(
            "Arial",
            Font.BOLD,
            14
        );

        // ================= HEADER =================

        header = new JPanel();

        header.setBackground(
            new Color(35,55,90)
        );

        header.setPreferredSize(
            new Dimension(1200,70)
        );

        title = new JLabel(
            "  RECENTLY DELETED CONTACTS"
        );

        title.setForeground(Color.WHITE);
        title.setFont(titleFont);

        header.add(title);

        add(
            header,
            BorderLayout.NORTH
        );

        // ================= TABLE =================

        table = new JTable();

        table.setFont(
            new Font(
                "Arial",
                Font.PLAIN,
                14
            )
        );

        table.setRowHeight(28);

        table.setSelectionMode(
            ListSelectionModel.SINGLE_SELECTION
        );

        sp = new JScrollPane(table);

        add(
            sp,
            BorderLayout.CENTER
        );

        // ================= BUTTONS =================

        bottom = new JPanel();

        restore = new JButton(
            "Restore Contact"
        );

        permanentDelete = new JButton(
            "Delete Permanently"
        );

        emptyTrash = new JButton(
            "Empty Trash"
        );

        refresh = new JButton(
            "Refresh"
        );

        back = new JButton(
            "Back"
        );

        JButton[] buttons =
        {
            restore,
            permanentDelete,
            emptyTrash,
            refresh,
            back
        };

        for(JButton b : buttons)
        {
            b.setFont(buttonFont);
            b.addActionListener(this);

            bottom.add(b);
        }

        add(
            bottom,
            BorderLayout.SOUTH
        );

        // ================= LOAD DATA =================

        showTrash();

        setVisible(true);
    }

    // ==================================================
    // SHOW TRASH CONTACTS
    // ==================================================

    public void showTrash()
    {
        try
        {
            ConnectionClass obj =
                new ConnectionClass();

            String q =
                "select * from trash_contact "
                + "order by deleted_date desc";

            ResultSet rs =
                obj.stm.executeQuery(q);

            DefaultTableModel model =
                new DefaultTableModel();

            model.addColumn("ID");
            model.addColumn("Contact ID");
            model.addColumn("Name");
            model.addColumn("Nickname");
            model.addColumn("Phone");
            model.addColumn("Mobile");
            model.addColumn("Email");
            model.addColumn("Address");
            model.addColumn("Company");
            model.addColumn("Position");
            model.addColumn("Group");
            model.addColumn("Favorite");
            model.addColumn("Deleted Date");

            while(rs.next())
            {
                model.addRow(
                    new Object[]
                    {
                        rs.getInt("id"),

                        rs.getInt("contact_id"),

                        rs.getString("name"),

                        rs.getString("nickname"),

                        rs.getString("phone"),

                        rs.getString("mobile"),

                        rs.getString("email"),

                        rs.getString("address"),

                        rs.getString("company"),

                        rs.getString("position"),

                        rs.getString("group_name"),

                        rs.getString("favorite"),

                        rs.getTimestamp(
                            "deleted_date"
                        )
                    }
                );
            }

            table.setModel(model);

            rs.close();
        }
        catch(Exception ex)
        {
            ex.printStackTrace();

            JOptionPane.showMessageDialog(
                this,
                "Error loading Trash:\n"
                + ex.getMessage()
            );
        }
    }

    // ==================================================
    // RESTORE CONTACT
    // ==================================================

    public void restoreContact()
    {
        int row =
            table.getSelectedRow();

        if(row == -1)
        {
            JOptionPane.showMessageDialog(
                this,
                "Please select a contact."
            );

            return;
        }

        int trashId =
            Integer.parseInt(
                table.getValueAt(row,0)
                .toString()
            );

        try
        {
            ConnectionClass obj =
                new ConnectionClass();

            // ================= GET CONTACT =================

            String q1 =
                "select * from trash_contact "
                + "where id="
                + trashId;

            ResultSet rs =
                obj.stm.executeQuery(q1);

            if(rs.next())
            {
                String name =
                    rs.getString("name");

                String nickname =
                    rs.getString("nickname");

                String phone =
                    rs.getString("phone");

                String mobile =
                    rs.getString("mobile");

                String email =
                    rs.getString("email");

                String address =
                    rs.getString("address");

                String company =
                    rs.getString("company");

                String position =
                    rs.getString("position");

                String group =
                    rs.getString("group_name");

                String favorite =
                    rs.getString("favorite");

                // ================= RESTORE TO ADD_CONTACT =================

                String q2 =
                    "insert into add_contact "
                    + "(name,nickname,phone,mobile,"
                    + "email,address,company,position,"
                    + "group_name,favorite) values("
                    + "'" + name + "',"
                    + "'" + nickname + "',"
                    + "'" + phone + "',"
                    + "'" + mobile + "',"
                    + "'" + email + "',"
                    + "'" + address + "',"
                    + "'" + company + "',"
                    + "'" + position + "',"
                    + "'" + group + "',"
                    + "'" + favorite + "')";

                int result =
                    obj.stm.executeUpdate(q2);

                if(result == 1)
                {
                    // ================= RESTORE FAVORITE =================

                    if(favorite != null &&
                       favorite.equalsIgnoreCase("YES"))
                    {
                        String q3 =
                            "insert into favorite_contact "
                            + "(name,nickname,phone,mobile,"
                            + "email,address,company,position,"
                            + "group_name) values("
                            + "'" + name + "',"
                            + "'" + nickname + "',"
                            + "'" + phone + "',"
                            + "'" + mobile + "',"
                            + "'" + email + "',"
                            + "'" + address + "',"
                            + "'" + company + "',"
                            + "'" + position + "',"
                            + "'" + group + "')";

                        obj.stm.executeUpdate(q3);
                    }

                    // ================= REMOVE FROM TRASH =================

                    String q4 =
                        "delete from trash_contact "
                        + "where id="
                        + trashId;

                    obj.stm.executeUpdate(q4);

                    JOptionPane.showMessageDialog(
                        this,
                        "Contact Restored Successfully!"
                    );

                    showTrash();
                }
            }

            rs.close();
        }
        catch(Exception ex)
        {
            ex.printStackTrace();

            JOptionPane.showMessageDialog(
                this,
                "Error restoring contact:\n"
                + ex.getMessage()
            );
        }
    }

    // ==================================================
    // PERMANENT DELETE
    // ==================================================

    public void deletePermanently()
    {
        int row =
            table.getSelectedRow();

        if(row == -1)
        {
            JOptionPane.showMessageDialog(
                this,
                "Please select a contact."
            );

            return;
        }

        int trashId =
            Integer.parseInt(
                table.getValueAt(row,0)
                .toString()
            );

        int result =
            JOptionPane.showConfirmDialog(
                this,
                "Delete this contact permanently?",
                "Permanent Delete",
                JOptionPane.YES_NO_OPTION
            );

        if(result == JOptionPane.YES_OPTION)
        {
            try
            {
                ConnectionClass obj =
                    new ConnectionClass();

                String q =
                    "delete from trash_contact "
                    + "where id="
                    + trashId;

                int deleted =
                    obj.stm.executeUpdate(q);

                if(deleted == 1)
                {
                    JOptionPane.showMessageDialog(
                        this,
                        "Contact Permanently Deleted!"
                    );

                    showTrash();
                }
            }
            catch(Exception ex)
            {
                ex.printStackTrace();

                JOptionPane.showMessageDialog(
                    this,
                    "Error deleting contact:\n"
                    + ex.getMessage()
                );
            }
        }
    }

    // ==================================================
    // EMPTY TRASH
    // ==================================================

    public void emptyTrash()
    {
        int result =
            JOptionPane.showConfirmDialog(
                this,
                "Are you sure you want to empty Trash?",
                "Empty Trash",
                JOptionPane.YES_NO_OPTION
            );

        if(result == JOptionPane.YES_OPTION)
        {
            try
            {
                ConnectionClass obj =
                    new ConnectionClass();

                String q =
                    "delete from trash_contact";

                obj.stm.executeUpdate(q);

                JOptionPane.showMessageDialog(
                    this,
                    "Trash Emptied Successfully!"
                );

                showTrash();
            }
            catch(Exception ex)
            {
                ex.printStackTrace();

                JOptionPane.showMessageDialog(
                    this,
                    "Error emptying Trash:\n"
                    + ex.getMessage()
                );
            }
        }
    }

    // ==================================================
    // BUTTON ACTIONS
    // ==================================================

    public void actionPerformed(
        ActionEvent e
    )
    {
        if(e.getSource() == restore)
        {
            restoreContact();
        }

        if(e.getSource() == permanentDelete)
        {
            deletePermanently();
        }

        if(e.getSource() == emptyTrash)
        {
            emptyTrash();
        }

        if(e.getSource() == refresh)
        {
            showTrash();
        }

        if(e.getSource() == back)
        {
            this.setVisible(false);

            new Dashboard().setVisible(true);
        }
    }

    // ==================================================
    // MAIN
    // ==================================================

    public static void main(String args[])
    {
        new TrashContacts();
    }
}
