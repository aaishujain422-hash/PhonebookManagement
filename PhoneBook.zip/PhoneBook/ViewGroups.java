package PhoneBook;

import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableCellEditor;

public class ViewGroups extends JFrame implements ActionListener
{
    JLabel title;

    JTable table;
    JScrollPane sp;

    JButton refresh;
    JButton back;

    JPanel header;
    JPanel bottom;

    Font titleFont;
    Font buttonFont;

    ViewGroups()
    {
        super("View Groups");

        setSize(750,600);

        setLocationRelativeTo(null);

        setDefaultCloseOperation(
            JFrame.DISPOSE_ON_CLOSE
        );

        setLayout(
            new BorderLayout(10,10)
        );

        titleFont =
            new Font(
                "Arial",
                Font.BOLD,
                26
            );

        buttonFont =
            new Font(
                "Arial",
                Font.BOLD,
                14
            );

        /*
         * HEADER
         */

        header = new JPanel();

        header.setBackground(
            new Color(35,55,90)
        );

        header.setPreferredSize(
            new Dimension(750,70)
        );

        title = new JLabel(
            "CONTACT GROUPS"
        );

        title.setFont(titleFont);

        title.setForeground(
            Color.WHITE
        );

        title.setHorizontalAlignment(
            JLabel.CENTER
        );

        header.add(title);

        add(
            header,
            BorderLayout.NORTH
        );

        /*
         * TABLE
         */

        table = new JTable();

        table.setFont(
            new Font(
                "Arial",
                Font.PLAIN,
                15
            )
        );

        table.setRowHeight(40);

        table.setSelectionMode(
            ListSelectionModel.SINGLE_SELECTION
        );

        sp = new JScrollPane(table);

        add(
            sp,
            BorderLayout.CENTER
        );

        /*
         * BOTTOM BUTTONS
         */

        bottom = new JPanel();

        refresh = new JButton(
            "Refresh"
        );

        back = new JButton(
            "Back"
        );

        refresh.setFont(buttonFont);
        back.setFont(buttonFont);

        refresh.addActionListener(this);
        back.addActionListener(this);

        bottom.add(refresh);
        bottom.add(back);

        add(
            bottom,
            BorderLayout.SOUTH
        );

        showGroups();
    }

    /*
     * SHOW GROUPS
     */

    public void showGroups()
    {
        try
        {
            ConnectionClass obj =
                new ConnectionClass();

            String q =
                "select group_name, count(*) as total "
                + "from add_contact "
                + "where group_name is not null "
                + "and group_name<>'' "
                + "group by group_name "
                + "order by group_name";

            ResultSet rs =
                obj.stm.executeQuery(q);

            DefaultTableModel model =
                new DefaultTableModel()
                {
                    public boolean isCellEditable(
                        int row,
                        int column)
                    {
                        return column == 2;
                    }
                };

            model.addColumn("Group Name");

            model.addColumn("Total Contacts");

            model.addColumn("Action");

            while(rs.next())
            {
                model.addRow(
                    new Object[]
                    {
                        rs.getString("group_name"),
                        rs.getInt("total"),
                        "VIEW CONTACTS"
                    }
                );
            }

            table.setModel(model);

            /*
             * VIEW BUTTON
             */

            table.getColumnModel()
                .getColumn(2)
                .setCellRenderer(
                    new ButtonRenderer()
                );

            table.getColumnModel()
                .getColumn(2)
                .setCellEditor(
                    new ButtonEditor(
                        new JCheckBox()
                    )
                );

            table.getColumnModel()
                .getColumn(0)
                .setPreferredWidth(350);

            table.getColumnModel()
                .getColumn(1)
                .setPreferredWidth(150);

            table.getColumnModel()
                .getColumn(2)
                .setPreferredWidth(200);

            rs.close();
        }
        catch(Exception ex)
        {
            ex.printStackTrace();

            JOptionPane.showMessageDialog(
                this,
                "Error loading groups:\n"
                + ex.getMessage()
            );
        }
    }

    /*
     * BUTTON DESIGN
     */

    class ButtonRenderer
        extends JButton
        implements TableCellRenderer
    {
        ButtonRenderer()
        {
            setOpaque(true);

            setFont(
                new Font(
                    "Arial",
                    Font.BOLD,
                    12
                )
            );
        }

        public Component
        getTableCellRendererComponent(
            JTable table,
            Object value,
            boolean isSelected,
            boolean hasFocus,
            int row,
            int column)
        {
            setText(
                "VIEW CONTACTS"
            );

            return this;
        }
    }

    /*
     * BUTTON CLICK
     */

    class ButtonEditor
        extends DefaultCellEditor
    {
        JButton button;

        String groupName;

        boolean clicked;

        ButtonEditor(JCheckBox checkBox)
        {
            super(checkBox);

            button =
                new JButton(
                    "VIEW CONTACTS"
                );

            button.setOpaque(true);

            button.setFont(
                new Font(
                    "Arial",
                    Font.BOLD,
                    12
                )
            );

            button.addActionListener(
                new ActionListener()
                {
                    public void actionPerformed(
                        ActionEvent e)
                    {
                        fireEditingStopped();
                    }
                }
            );
        }

        public Component
        getTableCellEditorComponent(
            JTable table,
            Object value,
            boolean isSelected,
            int row,
            int column)
        {
            groupName =
                table.getValueAt(
                    row,
                    0
                ).toString();

            clicked = true;

            return button;
        }

        public Object getCellEditorValue()
        {
            if(clicked)
            {
                showGroupContacts(
                    groupName
                );
            }

            clicked = false;

            return "VIEW CONTACTS";
        }
    }

    /*
     * SHOW CONTACTS OF SELECTED GROUP
     */

    public void showGroupContacts(
        String groupName)
    {
        try
        {
            ConnectionClass obj =
                new ConnectionClass();

            String q =
                "select id,name,phone,mobile,email "
                + "from add_contact "
                + "where group_name='"
                + groupName
                + "' "
                + "order by name";

            ResultSet rs =
                obj.stm.executeQuery(q);

            JFrame frame =
                new JFrame(
                    "Group - " + groupName
                );

            frame.setSize(
                700,
                500
            );

            frame.setLocationRelativeTo(
                this
            );

            String columns[] =
            {
                "ID",
                "Name",
                "Phone",
                "Mobile",
                "Email"
            };

            DefaultTableModel model =
                new DefaultTableModel(
                    columns,
                    0
                );

            while(rs.next())
            {
                model.addRow(
                    new Object[]
                    {
                        rs.getInt("id"),
                        rs.getString("name"),
                        rs.getString("phone"),
                        rs.getString("mobile"),
                        rs.getString("email")
                    }
                );
            }

            JTable contactTable =
                new JTable(model);

            contactTable.setFont(
                new Font(
                    "Arial",
                    Font.PLAIN,
                    14
                )
            );

            contactTable.setRowHeight(35);

            JScrollPane scroll =
                new JScrollPane(
                    contactTable
                );

            frame.add(scroll);

            frame.setVisible(true);

            rs.close();
        }
        catch(Exception ex)
        {
            ex.printStackTrace();

            JOptionPane.showMessageDialog(
                this,
                "Error:\n"
                + ex.getMessage()
            );
        }
    }

    /*
     * BUTTON ACTIONS
     */

    public void actionPerformed(
        ActionEvent e)
    {
        if(e.getSource() == refresh)
        {
            showGroups();
        }

        if(e.getSource() == back)
        {
            this.dispose();

            new Dashboard().setVisible(true);
        }
    }

    public static void main(
        String args[])
    {
        new ViewGroups().setVisible(true);
    }
}
