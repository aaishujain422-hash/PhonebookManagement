
package PhoneBook;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Home extends JFrame implements ActionListener
{
    JLabel title, subtitle, imageLabel;
    JButton bt1,bt2,bt3,bt4,bt5,bt6;
    JPanel sidebar, header, mainPanel;
    Font f1,f2;

    Home()
    {
        super("Phone Book Management");

        setSize(900,600);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Fonts
        f1 = new Font("Arial",Font.BOLD,25);
        f2 = new Font("Arial",Font.BOLD,15);

        // ================= HEADER =================

        header = new JPanel();
        header.setBackground(new Color(35,55,90));
        header.setPreferredSize(new Dimension(900,70));
        header.setLayout(new BorderLayout());

        title = new JLabel("   PHONE BOOK MANAGEMENT");
        title.setFont(f1);
        title.setForeground(Color.WHITE);

        JLabel user = new JLabel("Welcome   ");
        user.setFont(f2);
        user.setForeground(Color.WHITE);

        header.add(title,BorderLayout.WEST);
        header.add(user,BorderLayout.EAST);

        add(header,BorderLayout.NORTH);


        // ================= SIDEBAR =================

        sidebar = new JPanel();
        sidebar.setBackground(new Color(25,35,55));
        sidebar.setPreferredSize(new Dimension(210,530));

        sidebar.setLayout(new GridLayout(7,1,5,5));

        bt1 = new JButton("  ADD CONTACT");
        bt2 = new JButton("  SEARCH");
        bt3 = new JButton("  EDIT CONTACT");
        bt4 = new JButton("  DELETE CONTACT");
        bt5 = new JButton("  DASHBOARD");
        bt6 = new JButton("  EXIT");

        JButton[] buttons =
        {
            bt1,bt2,bt3,bt4,bt5,bt6
        };

        for(JButton b : buttons)
        {
            b.setFont(f2);
            b.setForeground(Color.WHITE);
            b.setBackground(new Color(25,35,55));
            b.setFocusPainted(false);
            b.setBorderPainted(false);
            b.setHorizontalAlignment(SwingConstants.LEFT);
            b.addActionListener(this);
        }

        sidebar.add(new JLabel(""));
        sidebar.add(bt1);
        sidebar.add(bt2);
        sidebar.add(bt3);
        sidebar.add(bt4);
        sidebar.add(bt5);
        sidebar.add(bt6);

        add(sidebar,BorderLayout.WEST);


        // ================= MAIN PANEL =================

        mainPanel = new JPanel();
        mainPanel.setBackground(new Color(245,247,250));
        mainPanel.setLayout(null);

        JLabel welcome = new JLabel("Welcome to Phone Book");
        welcome.setFont(new Font("Arial",Font.BOLD,32));
        welcome.setBounds(50,50,500,50);

        mainPanel.add(welcome);


        subtitle = new JLabel(
            "Manage your contacts quickly and easily"
        );

        subtitle.setFont(new Font("Arial",Font.PLAIN,17));
        subtitle.setForeground(Color.GRAY);
        subtitle.setBounds(53,105,500,30);

        mainPanel.add(subtitle);


        // ================= IMAGE =================

        ImageIcon img =
            new ImageIcon(
                ClassLoader.getSystemResource("Image/book.png")
            );

        Image img2 =
            img.getImage().getScaledInstance(
                220,220,Image.SCALE_SMOOTH
            );

        ImageIcon img3 = new ImageIcon(img2);

        imageLabel = new JLabel(img3);
        imageLabel.setBounds(570,70,230,230);

        mainPanel.add(imageLabel);


        // ================= QUICK ACTIONS =================

        JLabel quick = new JLabel("Quick Actions");
        quick.setFont(new Font("Arial",Font.BOLD,22));
        quick.setBounds(55,180,250,40);

        mainPanel.add(quick);


        // Add Contact

        JButton addButton = new JButton("ADD CONTACT");
        addButton.setFont(f2);
        addButton.setBounds(55,240,190,55);
        addButton.addActionListener(this);

        mainPanel.add(addButton);


        // Search

        JButton searchButton = new JButton("SEARCH CONTACT");
        searchButton.setFont(f2);
        searchButton.setBounds(265,240,190,55);
        searchButton.addActionListener(this);

        mainPanel.add(searchButton);


        // Dashboard

        JButton dashboardButton = new JButton("DASHBOARD");
        dashboardButton.setFont(f2);
        dashboardButton.setBounds(55,315,190,55);
        dashboardButton.addActionListener(this);

        mainPanel.add(dashboardButton);


        // ================= BOTTOM TEXT =================

        JLabel bottomText = new JLabel(
            "Use the menu on the left to manage your contacts."
        );

        bottomText.setFont(
            new Font("Arial",Font.PLAIN,14)
        );

        bottomText.setForeground(Color.GRAY);
        bottomText.setBounds(55,420,500,30);

        mainPanel.add(bottomText);


        add(mainPanel,BorderLayout.CENTER);
    }


    // ================= BUTTON ACTIONS =================

    public void actionPerformed(ActionEvent e)
    {
        // ADD CONTACT
        if(e.getSource()==bt1)
        {
            this.setVisible(false);
            new EntryData().setVisible(true);
        }


        // SEARCH
        if(e.getSource()==bt2)
        {
            this.setVisible(false);
            new SearchData().setVisible(true);
        }


        // EDIT
        if(e.getSource()==bt3)
        {
            this.setVisible(false);
            new SearchNameForEdit().setVisible(true);
        }


        // DELETE
        if(e.getSource()==bt4)
        {
            this.setVisible(false);
            new DeleteContact().setVisible(true);
        }


        // DASHBOARD
        if(e.getSource()==bt5)
        {
            this.setVisible(false);
            new Dashboard().setVisible(true);
        }


        // EXIT
        if(e.getSource()==bt6)
        {
            int result = JOptionPane.showConfirmDialog(
                this,
                "Do you want to exit?",
                "Exit",
                JOptionPane.YES_NO_OPTION
            );

            if(result == JOptionPane.YES_OPTION)
            {
                System.exit(0);
            }
        }


        // Quick Add Button
        if(e.getActionCommand().equals("ADD CONTACT"))
        {
            this.setVisible(false);
            new EntryData().setVisible(true);
        }


        // Quick Search Button
        if(e.getActionCommand().equals("SEARCH CONTACT"))
        {
            this.setVisible(false);
            new SearchData().setVisible(true);
        }


        // Quick Dashboard Button
        if(e.getActionCommand().equals("DASHBOARD"))
        {
            this.setVisible(false);
            new Dashboard().setVisible(true);
        }
    }


    public static void main(String[] args)
    {
        new Home().setVisible(true);
    }
}