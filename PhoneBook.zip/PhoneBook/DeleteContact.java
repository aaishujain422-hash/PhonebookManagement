package PhoneBook;

import java.awt.*;
import java.sql.*;
import java.awt.event.*;
import javax.swing.*;

public class DeleteContact extends JFrame implements ActionListener
{
    String x[]={"Id","Name","Nick Name","Phone","Mobile","Email","Address","Company","Position","Group Name"};
    JButton bt;
    String y[][]=new String[100][10];
    int i=0,j=0;
    JTable t;
    Font f,f1;
    JLabel l1;
    JTextField tf;
    JPanel p1,p2;

    DeleteContact()
    {
        super("Delete Contact");
        setSize(800,400);
        setLocation(1,1);

        f=new Font("MS UI Gothic",Font.BOLD,15);

        try
        {
            ConnectionClass obj=new ConnectionClass();

            String q="select * from add_contact";

            ResultSet rest=obj.stm.executeQuery(q);

            while(rest.next())
            {
                y[i][j++]=rest.getString("id");
                y[i][j++]=rest.getString("name");
                y[i][j++]=rest.getString("nickname");
                y[i][j++]=rest.getString("phone");
                y[i][j++]=rest.getString("mobile");
                y[i][j++]=rest.getString("email");
                y[i][j++]=rest.getString("address");
                y[i][j++]=rest.getString("company");
                y[i][j++]=rest.getString("position");
                y[i][j++]=rest.getString("group_name");

                i++;
                j=0;
            }

            t=new JTable(y,x);
            t.setFont(f);
            t.setRowHeight(25);
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
        }

        JScrollPane sp=new JScrollPane(t);

        l1=new JLabel("Enter Contact ID for Delete");
        tf=new JTextField();

        bt=new JButton("Delete");
        bt.setBackground(Color.RED);
        bt.setForeground(Color.WHITE);

        bt.addActionListener(this);

        p1=new JPanel();
        p1.setLayout(new GridLayout(1,3,10,10));

        p1.add(l1);
        p1.add(tf);
        p1.add(bt);

        setLayout(new BorderLayout(10,10));

        add(p1,"South");
        add(sp,"Center");
    }

    public void actionPerformed(ActionEvent e)
    {
        if(e.getSource()==bt)
        {
            if(tf.getText().trim().equals(""))
            {
                JOptionPane.showMessageDialog(
                    null,
                    "Please enter Contact ID."
                );
                return;
            }

            int idno;

            try
            {
                idno=Integer.parseInt(tf.getText().trim());
            }
            catch(Exception ex)
            {
                JOptionPane.showMessageDialog(
                    null,
                    "Please enter a valid Contact ID."
                );
                return;
            }

            try
            {
                ConnectionClass obj1=new ConnectionClass();

                /*
                 * First move contact to Trash
                 */
                String q1 =
                    "insert into trash_contact "
                    + "(contact_id,name,nickname,phone,mobile,email,"
                    + "address,company,position,group_name) "
                    + "select id,name,nickname,phone,mobile,email,"
                    + "address,company,position,group_name "
                    + "from add_contact "
                    + "where id=" + idno;

                int moved=obj1.stm.executeUpdate(q1);

                if(moved==1)
                {
                    /*
                     * Delete contact from Favorites
                     * using contact information.
                     */
                    String q2 =
                        "delete from favorite_contact "
                        + "where name=(select name from add_contact "
                        + "where id=" + idno + ") "
                        + "and phone=(select phone from add_contact "
                        + "where id=" + idno + ")";

                    obj1.stm.executeUpdate(q2);

                    /*
                     * Now delete contact from main table
                     */
                    String q3 =
                        "delete from add_contact "
                        + "where id=" + idno;

                    int deleted=obj1.stm.executeUpdate(q3);

                    if(deleted==1)
                    {
                        JOptionPane.showMessageDialog(
                            null,
                            "Contact moved to Trash successfully."
                        );

                        this.setVisible(false);
                        new DeleteContact().setVisible(true);
                    }
                    else
                    {
                        JOptionPane.showMessageDialog(
                            null,
                            "Contact could not be deleted."
                        );
                    }
                }
                else
                {
                    JOptionPane.showMessageDialog(
                        null,
                        "Contact ID not found."
                    );
                }
            }
            catch(Exception ex)
            {
                ex.printStackTrace();

                JOptionPane.showMessageDialog(
                    null,
                    "Error while deleting contact."
                );
            }
        }
    }

    public static void main(String[] args)
    {
        new DeleteContact().setVisible(true);
    }
}