package PhoneBook;

import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class GroupManagement extends JFrame implements ActionListener
{
    JLabel title,l1,l2;

    JTextField tf1,tf2;

    JButton add,delete,refresh,view,back;

    JTable table;

    JScrollPane sp;

    JPanel header,formPanel,buttonPanel;

    Font titleFont,labelFont,buttonFont;

    GroupManagement()
    {
        super("Group Management");

        setSize(850,600);

        setLocationRelativeTo(null);

        setDefaultCloseOperation(
            JFrame.DISPOSE_ON_CLOSE
        );

        titleFont=
            new Font(
                "Arial",
                Font.BOLD,
                26
            );

        labelFont=
            new Font(
                "Arial",
                Font.BOLD,
                15
            );

        buttonFont=
            new Font(
                "Arial",
                Font.BOLD,
                14
            );

        // ================= HEADER =================

        header=new JPanel();

        header.setBackground(
            new Color(35,55,90)
        );

        header.setPreferredSize(
            new Dimension(850,70)
        );

        header.setLayout(
            new BorderLayout()
        );

        title=
            new JLabel(
                "GROUP MANAGEMENT"
            );

        title.setFont(titleFont);

        title.setForeground(
            Color.WHITE
        );

        title.setHorizontalAlignment(
            JLabel.CENTER
        );

        header.add(
            title,
            BorderLayout.CENTER
        );

        // ================= FORM PANEL =================

        formPanel=new JPanel();

        formPanel.setLayout(
            new GridLayout(
                2,
                2,
                10,
                10
            )
        );

        formPanel.setBorder(
            BorderFactory.createEmptyBorder(
                15,
                20,
                15,
                20
            )
        );

        l1=
            new JLabel(
                "Group Name"
            );

        l2=
            new JLabel(
                "Description"
            );

        l1.setFont(labelFont);
        l2.setFont(labelFont);

        tf1=new JTextField();
        tf2=new JTextField();

        tf1.setFont(buttonFont);
        tf2.setFont(buttonFont);

        formPanel.add(l1);
        formPanel.add(tf1);

        formPanel.add(l2);
        formPanel.add(tf2);

        // ================= BUTTON PANEL =================

        buttonPanel=new JPanel();

        add=
            new JButton(
                "Add Group"
            );

        delete=
            new JButton(
                "Delete Group"
            );

        refresh=
            new JButton(
                "Refresh"
            );

        view=
            new JButton(
                "View Contacts"
            );

        back=
            new JButton(
                "Back"
            );

        JButton buttons[]=
        {
            add,
            delete,
            refresh,
            view,
            back
        };

        for(JButton b : buttons)
        {
            b.setFont(buttonFont);
            b.setFocusPainted(false);
            b.addActionListener(this);
            buttonPanel.add(b);
        }

        // ================= TABLE =================

        table=new JTable();

        table.setFont(
            new Font(
                "Arial",
                Font.PLAIN,
                14
            )
        );

        table.setRowHeight(35);

        table.setSelectionMode(
            ListSelectionModel.SINGLE_SELECTION
        );

        sp=
            new JScrollPane(table);

        // ================= LAYOUT =================

        setLayout(
            new BorderLayout(
                10,
                10
            )
        );

        add(
            header,
            BorderLayout.NORTH
        );

        add(
            formPanel,
            BorderLayout.WEST
        );

        add(
            sp,
            BorderLayout.CENTER
        );

        add(
            buttonPanel,
            BorderLayout.SOUTH
        );

        // ================= LOAD GROUPS =================

        showGroups();
    }

    // ==================================================
    // SHOW GROUPS
    // ==================================================

    public void showGroups()
    {
        try
        {
            ConnectionClass obj=
                new ConnectionClass();

            String q=
                "select id,group_name,description,created_date "
                + "from contact_groups "
                + "order by group_name";

            ResultSet rs=
                obj.stm.executeQuery(q);

            String columns[]=
            {
                "ID",
                "Group Name",
                "Description",
                "Created Date"
            };

            DefaultTableModel model=
                new DefaultTableModel(
                    columns,
                    0
                )
                {
                    public boolean isCellEditable(
                        int row,
                        int column)
                    {
                        return false;
                    }
                };

            while(rs.next())
            {
                model.addRow(
                    new Object[]
                    {
                        rs.getInt("id"),
                        rs.getString("group_name"),
                        rs.getString("description"),
                        rs.getTimestamp("created_date")
                    }
                );
            }

            table.setModel(model);

            table.getColumnModel()
                .getColumn(0)
                .setPreferredWidth(50);

            table.getColumnModel()
                .getColumn(1)
                .setPreferredWidth(180);

            table.getColumnModel()
                .getColumn(2)
                .setPreferredWidth(300);

            table.getColumnModel()
                .getColumn(3)
                .setPreferredWidth(180);

            rs.close();
        }
        catch(Exception ex)
        {
            ex.printStackTrace();

            JOptionPane.showMessageDialog(
                this,
                "Error loading groups:\n"
                + ex.getMessage()
            );
        }
    }

    // ==================================================
    // ADD GROUP
    // ==================================================

    public void addGroup()
    {
        String groupName=
            tf1.getText().trim();

        String description=
            tf2.getText().trim();

        if(groupName.equals(""))
        {
            JOptionPane.showMessageDialog(
                this,
                "Please enter group name."
            );

            return;
        }

        try
        {
            ConnectionClass obj=
                new ConnectionClass();

            String check=
                "select * from contact_groups "
                + "where group_name='"
                + groupName
                + "'";

            ResultSet rs=
                obj.stm.executeQuery(check);

            if(rs.next())
            {
                JOptionPane.showMessageDialog(
                    this,
                    "This group already exists."
                );

                rs.close();

                return;
            }

            rs.close();

            String q=
                "insert into contact_groups "
                + "(group_name,description) "
                + "values('"
                + groupName
                + "','"
                + description
                + "')";

            int result=
                obj.stm.executeUpdate(q);

            if(result==1)
            {
                JOptionPane.showMessageDialog(
                    this,
                    "Group added successfully."
                );

                tf1.setText("");
                tf2.setText("");

                showGroups();
            }
        }
        catch(Exception ex)
        {
            ex.printStackTrace();

            JOptionPane.showMessageDialog(
                this,
                "Error adding group:\n"
                + ex.getMessage()
            );
        }
    }

    // ==================================================
    // DELETE GROUP
    // ==================================================

    public void deleteGroup()
    {
        int row=
            table.getSelectedRow();

        if(row==-1)
        {
            JOptionPane.showMessageDialog(
                this,
                "Please select a group first."
            );

            return;
        }

        int id=
            Integer.parseInt(
                table
                .getValueAt(row,0)
                .toString()
            );

        String groupName=
            table
            .getValueAt(row,1)
            .toString();

        int result=
            JOptionPane.showConfirmDialog(
                this,
                "Delete group '"
                + groupName
                + "'?",
                "Delete Group",
                JOptionPane.YES_NO_OPTION
            );

        if(
            result!=
            JOptionPane.YES_OPTION
        )
        {
            return;
        }

        try
        {
            ConnectionClass obj=
                new ConnectionClass();

            // First remove group_id from contacts
            String q1=
                "update add_contact "
                + "set group_id=NULL "
                + "where group_id="
                + id;

            obj.stm.executeUpdate(q1);

            // Then delete group
            String q2=
                "delete from contact_groups "
                + "where id="
                + id;

            int aa=
                obj.stm.executeUpdate(q2);

            if(aa==1)
            {
                JOptionPane.showMessageDialog(
                    this,
                    "Group deleted successfully."
                );

                showGroups();
            }
        }
        catch(Exception ex)
        {
            ex.printStackTrace();

            JOptionPane.showMessageDialog(
                this,
                "Error deleting group:\n"
                + ex.getMessage()
            );
        }
    }

    // ==================================================
    // VIEW CONTACTS OF SELECTED GROUP
    // ==================================================

    public void viewContacts()
    {
        int row=
            table.getSelectedRow();

        if(row==-1)
        {
            JOptionPane.showMessageDialog(
                this,
                "Please select a group first."
            );

            return;
        }

        int groupId=
            Integer.parseInt(
                table
                .getValueAt(row,0)
                .toString()
            );

        String groupName=
            table
            .getValueAt(row,1)
            .toString();

        try
        {
            ConnectionClass obj=
                new ConnectionClass();

            /*
             * We check BOTH group_id and group_name.
             *
             * This allows old contacts to appear even
             * if their group_id is NULL.
             */

            String q=
                "select id,name,phone,mobile,email "
                + "from add_contact "
                + "where group_id="
                + groupId
                + " or group_name='"
                + groupName
                + "' "
                + "order by name";

            ResultSet rs=
                obj.stm.executeQuery(q);

            JFrame frame=
                new JFrame(
                    "Contacts - "
                    + groupName
                );

            frame.setSize(
                750,
                500
            );

            frame.setLocationRelativeTo(this);

            frame.setLayout(
                new BorderLayout()
            );

            // ================= TITLE =================

            JLabel groupTitle=
                new JLabel(
                    "  "
                    + groupName
                    + " - CONTACTS"
                );

            groupTitle.setFont(
                new Font(
                    "Arial",
                    Font.BOLD,
                    20
                )
            );

            groupTitle.setForeground(
                Color.WHITE
            );

            groupTitle.setOpaque(true);

            groupTitle.setBackground(
                new Color(35,55,90)
            );

            groupTitle.setPreferredSize(
                new Dimension(
                    750,
                    55
                )
            );

            frame.add(
                groupTitle,
                BorderLayout.NORTH
            );

            // ================= TABLE =================

            String columns[]=
            {
                "ID",
                "Name",
                "Phone",
                "Mobile",
                "Email"
            };

            DefaultTableModel model=
                new DefaultTableModel(
                    columns,
                    0
                )
                {
                    public boolean isCellEditable(
                        int row,
                        int column)
                    {
                        return false;
                    }
                };

            int count=0;

            while(rs.next())
            {
                model.addRow(
                    new Object[]
                    {
                        rs.getInt("id"),
                        rs.getString("name"),
                        rs.getString("phone"),
                        rs.getString("mobile"),
                        rs.getString("email")
                    }
                );

                count++;
            }

            rs.close();

            JTable contactTable=
                new JTable(model);

            contactTable.setFont(
                new Font(
                    "Arial",
                    Font.PLAIN,
                    14
                )
            );

            contactTable.setRowHeight(35);

            JScrollPane scroll=
                new JScrollPane(
                    contactTable
                );

            frame.add(
                scroll,
                BorderLayout.CENTER
            );

            // ================= BOTTOM =================

            JPanel bottom=
                new JPanel();

            JButton close=
                new JButton(
                    "Close"
                );

            close.setFont(buttonFont);

            close.addActionListener(
                new ActionListener()
                {
                    public void actionPerformed(
                        ActionEvent e)
                    {
                        frame.dispose();
                    }
                }
            );

            bottom.add(close);

            frame.add(
                bottom,
                BorderLayout.SOUTH
            );

            frame.setVisible(true);

            // ================= NO CONTACTS =================

            if(count==0)
            {
                JOptionPane.showMessageDialog(
                    this,
                    "No contacts found in "
                    + groupName
                    + "."
                );
            }
        }
        catch(Exception ex)
        {
            ex.printStackTrace();

            JOptionPane.showMessageDialog(
                this,
                "Error loading contacts:\n"
                + ex.getMessage()
            );
        }
    }

    // ==================================================
    // BUTTON ACTION
    // ==================================================

    public void actionPerformed(
        ActionEvent e)
    {
        if(e.getSource()==add)
        {
            addGroup();
        }

        if(e.getSource()==delete)
        {
            deleteGroup();
        }

        if(e.getSource()==refresh)
        {
            showGroups();
        }

        if(e.getSource()==view)
        {
            viewContacts();
        }

        if(e.getSource()==back)
        {
            this.dispose();

            new Dashboard().setVisible(true);
        }
    }

    // ==================================================
    // MAIN
    // ==================================================

    public static void main(
        String args[])
    {
        new GroupManagement().setVisible(true);
    }
}
