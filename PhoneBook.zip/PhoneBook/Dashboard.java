package PhoneBook;

import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import javax.swing.*;

public class Dashboard extends JFrame implements ActionListener
{
    JLabel title, welcome, totalTitle, totalValue;
    JLabel recentTitle;

    JButton home, view, groups, favorite, statistics, trash, logout;

    JPanel sidebar, header, mainPanel;
    JPanel card1, card2, card3;

    Font titleFont, buttonFont, normalFont;

    JLabel favValue;

    Dashboard()
    {
        super("Phone Book Management - Dashboard");

        setSize(900, 600);

        setLocationRelativeTo(null);

        setLayout(new BorderLayout());

        setDefaultCloseOperation(
            JFrame.EXIT_ON_CLOSE
        );

        // ================= FONTS =================

        titleFont =
            new Font(
                "Arial",
                Font.BOLD,
                26
            );

        buttonFont =
            new Font(
                "Arial",
                Font.BOLD,
                15
            );

        normalFont =
            new Font(
                "Arial",
                Font.PLAIN,
                15
            );

        // ================= HEADER =================

        header = new JPanel();

        header.setBackground(
            new Color(35, 55, 90)
        );

        header.setPreferredSize(
            new Dimension(900, 75)
        );

        header.setLayout(
            new BorderLayout()
        );

        title =
            new JLabel(
                "  PHONE BOOK MANAGEMENT"
            );

        title.setForeground(
            Color.WHITE
        );

        title.setFont(
            titleFont
        );

        welcome =
            new JLabel(
                "Welcome!   "
            );

        welcome.setForeground(
            Color.WHITE
        );

        welcome.setFont(
            buttonFont
        );

        header.add(
            title,
            BorderLayout.WEST
        );

        header.add(
            welcome,
            BorderLayout.EAST
        );

        add(
            header,
            BorderLayout.NORTH
        );

        // ================= SIDEBAR =================

        sidebar = new JPanel();

        sidebar.setBackground(
            new Color(25, 35, 55)
        );

        sidebar.setPreferredSize(
            new Dimension(210, 525)
        );

        /*
         * 8 rows =
         * blank space + 7 buttons
         */

        sidebar.setLayout(
            new GridLayout(
                8,
                1,
                5,
                5
            )
        );

        home =
            new JButton(
                "  HOME"
            );

        view =
            new JButton(
                "  VIEW CONTACTS"
            );

        groups =
            new JButton(
                "  GROUP MANAGEMENT"
            );

        favorite =
            new JButton(
                "  FAVORITES"
            );

        statistics =
            new JButton(
                "  STATISTICS"
            );

        trash =
            new JButton(
                "  RECENTLY DELETED"
            );

        logout =
            new JButton(
                "  LOGOUT"
            );

        // ================= BUTTONS ARRAY =================

        JButton[] buttons =
        {
            home,
            view,
            groups,
            favorite,
            statistics,
            trash,
            logout
        };

        // ================= BUTTON DESIGN =================

        for(JButton b : buttons)
        {
            b.setFont(
                buttonFont
            );

            b.setForeground(
                Color.WHITE
            );

            b.setBackground(
                new Color(25, 35, 55)
            );

            b.setFocusPainted(
                false
            );

            b.setBorderPainted(
                false
            );

            b.setHorizontalAlignment(
                SwingConstants.LEFT
            );

            b.addActionListener(
                this
            );
        }

        // ================= SIDEBAR BUTTONS =================

        sidebar.add(
            new JLabel("")
        );

        sidebar.add(
            home
        );

        sidebar.add(
            view
        );

        sidebar.add(
            groups
        );

        sidebar.add(
            favorite
        );

        sidebar.add(
            statistics
        );

        sidebar.add(
            trash
        );

        sidebar.add(
            logout
        );

        add(
            sidebar,
            BorderLayout.WEST
        );

        // ================= MAIN PANEL =================

        mainPanel =
            new JPanel();

        mainPanel.setBackground(
            new Color(245, 247, 250)
        );

        mainPanel.setLayout(
            null
        );

        JLabel dashboardTitle =
            new JLabel(
                "Dashboard"
            );

        dashboardTitle.setFont(
            new Font(
                "Arial",
                Font.BOLD,
                30
            )
        );

        dashboardTitle.setBounds(
            40,
            30,
            300,
            40
        );

        mainPanel.add(
            dashboardTitle
        );

        JLabel subtitle =
            new JLabel(
                "Manage your contacts easily"
            );

        subtitle.setFont(
            normalFont
        );

        subtitle.setForeground(
            Color.GRAY
        );

        subtitle.setBounds(
            42,
            70,
            300,
            25
        );

        mainPanel.add(
            subtitle
        );

        // ================= CARD 1 =================

        card1 =
            new JPanel();

        card1.setBackground(
            Color.WHITE
        );

        card1.setLayout(
            null
        );

        card1.setBounds(
            40,
            120,
            180,
            120
        );

        JLabel c1title =
            new JLabel(
                "TOTAL CONTACTS"
            );

        c1title.setFont(
            new Font(
                "Arial",
                Font.BOLD,
                13
            )
        );

        c1title.setBounds(
            20,
            20,
            150,
            25
        );

        totalValue =
            new JLabel(
                "0"
            );

        totalValue.setFont(
            new Font(
                "Arial",
                Font.BOLD,
                32
            )
        );

        totalValue.setBounds(
            20,
            50,
            100,
            40
        );

        card1.add(
            c1title
        );

        card1.add(
            totalValue
        );

        mainPanel.add(
            card1
        );

        // ================= CARD 2 =================

        card2 =
            new JPanel();

        card2.setBackground(
            Color.WHITE
        );

        card2.setLayout(
            null
        );

        card2.setBounds(
            240,
            120,
            180,
            120
        );

        JLabel c2title =
            new JLabel(
                "FAVORITES"
            );

        c2title.setFont(
            new Font(
                "Arial",
                Font.BOLD,
                13
            )
        );

        c2title.setBounds(
            20,
            20,
            150,
            25
        );

        favValue =
            new JLabel(
                "0"
            );

        favValue.setFont(
            new Font(
                "Arial",
                Font.BOLD,
                32
            )
        );

        favValue.setBounds(
            20,
            50,
            100,
            40
        );

        card2.add(
            c2title
        );

        card2.add(
            favValue
        );

        mainPanel.add(
            card2
        );

        // ================= CARD 3 =================

        card3 =
            new JPanel();

        card3.setBackground(
            Color.WHITE
        );

        card3.setLayout(
            null
        );

        card3.setBounds(
            440,
            120,
            180,
            120
        );

        JLabel c3title =
            new JLabel(
                "PHONE BOOK"
            );

        c3title.setFont(
            new Font(
                "Arial",
                Font.BOLD,
                13
            )
        );

        c3title.setBounds(
            20,
            20,
            150,
            25
        );

        JLabel c3value =
            new JLabel(
                "ACTIVE"
            );

        c3value.setFont(
            new Font(
                "Arial",
                Font.BOLD,
                22
            )
        );

        c3value.setBounds(
            20,
            50,
            150,
            40
        );

        card3.add(
            c3title
        );

        card3.add(
            c3value
        );

        mainPanel.add(
            card3
        );

        // ================= QUICK ACTIONS =================

        recentTitle =
            new JLabel(
                "Quick Actions"
            );

        recentTitle.setFont(
            new Font(
                "Arial",
                Font.BOLD,
                20
            )
        );

        recentTitle.setBounds(
            40,
            275,
            250,
            30
        );

        mainPanel.add(
            recentTitle
        );

        // ================= QUICK VIEW =================

        JButton quickView =
            new JButton(
                "View All Contacts"
            );

        quickView.setBounds(
            40,
            320,
            180,
            45
        );

        quickView.setFont(
            buttonFont
        );

        quickView.addActionListener(
            this
        );

        mainPanel.add(
            quickView
        );

        // ================= QUICK GROUP MANAGEMENT =================

        JButton quickGroups =
            new JButton(
                "Group Management"
            );

        quickGroups.setBounds(
            240,
            320,
            180,
            45
        );

        quickGroups.setFont(
            buttonFont
        );

        quickGroups.addActionListener(
            this
        );

        mainPanel.add(
            quickGroups
        );

        // ================= INFORMATION =================

        JLabel info =
            new JLabel(
                "Use the menu on the left to manage your phone book."
            );

        info.setFont(
            normalFont
        );

        info.setForeground(
            Color.GRAY
        );

        info.setBounds(
            40,
            410,
            550,
            30
        );

        mainPanel.add(
            info
        );

        add(
            mainPanel,
            BorderLayout.CENTER
        );

        // ================= LOAD DATABASE VALUES =================

        loadDashboardData();

        setVisible(true);
    }

    // ==================================================
    // LOAD TOTAL CONTACTS AND FAVORITES
    // ==================================================

    public void loadDashboardData()
    {
        try
        {
            ConnectionClass obj =
                new ConnectionClass();

            // ================= TOTAL CONTACTS =================

            String q1 =
                "select count(*) from add_contact";

            ResultSet rs1 =
                obj.stm.executeQuery(q1);

            if(rs1.next())
            {
                totalValue.setText(
                    String.valueOf(
                        rs1.getInt(1)
                    )
                );
            }

            // ================= TOTAL FAVORITES =================

            String q2 =
                "select count(*) from favorite_contact";

            ResultSet rs2 =
                obj.stm.executeQuery(q2);

            if(rs2.next())
            {
                favValue.setText(
                    String.valueOf(
                        rs2.getInt(1)
                    )
                );
            }

            rs1.close();
            rs2.close();
        }
        catch(Exception ex)
        {
            ex.printStackTrace();

            JOptionPane.showMessageDialog(
                this,
                "Error loading dashboard data:\n"
                + ex.getMessage()
            );
        }
    }

    // ==================================================
    // BUTTON ACTIONS
    // ==================================================

    public void actionPerformed(
        ActionEvent e)
    {
        // ================= HOME =================

        if(e.getSource() == home)
        {
            new Home().setVisible(true);

            this.setVisible(false);
        }

        // ================= VIEW CONTACTS =================

        if(e.getSource() == view)
        {
            new ViewContacts().setVisible(true);

            this.setVisible(false);
        }

        // ================= GROUP MANAGEMENT =================

        if(e.getSource() == groups)
        {
            new GroupManagement().setVisible(true);

            this.setVisible(false);
        }

        // ================= FAVORITES =================

        if(e.getSource() == favorite)
        {
            new FavoriteContacts().setVisible(true);

            this.setVisible(false);
        }

        // ================= STATISTICS =================

        if(e.getSource() == statistics)
        {
            new ContactStatistics().setVisible(true);

            this.setVisible(false);
        }

        // ================= RECENTLY DELETED =================

        if(e.getSource() == trash)
        {
            new TrashContacts().setVisible(true);

            this.setVisible(false);
        }

        // ================= LOGOUT =================

        if(e.getSource() == logout)
        {
            int result =
                JOptionPane.showConfirmDialog(
                    this,
                    "Do you want to logout?",
                    "Logout",
                    JOptionPane.YES_NO_OPTION
                );

            if(
                result ==
                JOptionPane.YES_OPTION
            )
            {
                new Login().setVisible(true);

                this.setVisible(false);
            }
        }

        // ==================================================
        // QUICK ACTION BUTTONS
        // ==================================================

        if(e.getSource() instanceof JButton)
        {
            JButton button =
                (JButton)e.getSource();

            // ================= VIEW ALL =================

            if(
                button.getText()
                .contains("View All")
            )
            {
                new ViewContacts().setVisible(true);

                this.setVisible(false);
            }

            // ================= GROUP MANAGEMENT =================

            if(
                button.getText()
                .contains("Group Management")
            )
            {
                new GroupManagement().setVisible(true);

                this.setVisible(false);
            }
        }
    }

    // ==================================================
    // MAIN
    // ==================================================

    public static void main(
        String args[])
    {
        new Dashboard();
    }
}