package PhoneBook;

import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableCellEditor;

public class ViewContacts extends JFrame implements ActionListener
{
    JLabel title;

    JButton refresh;
    JButton back;

    JTable table;
    JScrollPane sp;

    JPanel header;
    JPanel bottom;

    Font titleFont;
    Font buttonFont;

    ViewContacts()
    {
        super("View All Contacts");

        setSize(700,600);

        setLocationRelativeTo(null);

        setDefaultCloseOperation(
            JFrame.DISPOSE_ON_CLOSE
        );

        setLayout(
            new BorderLayout(10,10)
        );

        titleFont =
            new Font(
                "Arial",
                Font.BOLD,
                26
            );

        buttonFont =
            new Font(
                "Arial",
                Font.BOLD,
                14
            );

        /*
         * HEADER
         */

        header = new JPanel();

        header.setBackground(
            new Color(35,55,90)
        );

        header.setPreferredSize(
            new Dimension(700,70)
        );

        title = new JLabel(
            "ALL CONTACTS"
        );

        title.setForeground(
            Color.WHITE
        );

        title.setFont(
            titleFont
        );

        title.setHorizontalAlignment(
            JLabel.CENTER
        );

        header.add(title);

        add(
            header,
            BorderLayout.NORTH
        );

        /*
         * TABLE
         */

        table = new JTable();

        table.setFont(
            new Font(
                "Arial",
                Font.PLAIN,
                15
            )
        );

        table.setRowHeight(40);

        table.setSelectionMode(
            ListSelectionModel.SINGLE_SELECTION
        );

        sp = new JScrollPane(table);

        add(
            sp,
            BorderLayout.CENTER
        );

        /*
         * BOTTOM
         */

        bottom = new JPanel();

        refresh = new JButton(
            "Refresh"
        );

        back = new JButton(
            "Back"
        );

        refresh.setFont(buttonFont);
        back.setFont(buttonFont);

        refresh.addActionListener(this);
        back.addActionListener(this);

        bottom.add(refresh);
        bottom.add(back);

        add(
            bottom,
            BorderLayout.SOUTH
        );

        showContacts();
    }

    /*
     * SHOW ALL CONTACTS
     */

    public void showContacts()
    {
        try
        {
            ConnectionClass obj =
                new ConnectionClass();

            String q =
                "select id,name from add_contact "
                + "order by id";

            ResultSet rs =
                obj.stm.executeQuery(q);

            DefaultTableModel model =
                new DefaultTableModel()
                {
                    public boolean isCellEditable(
                        int row,
                        int column)
                    {
                        /*
                         * IMPORTANT:
                         * VIEW button is column 2
                         */

                        return column == 2;
                    }
                };

            model.addColumn("ID");
            model.addColumn("Contact Name");
            model.addColumn("Action");

            while(rs.next())
            {
                model.addRow(
                    new Object[]
                    {
                        rs.getInt("id"),
                        rs.getString("name"),
                        "VIEW"
                    }
                );
            }

            table.setModel(model);

            /*
             * HIDE ID COLUMN
             */

            table.getColumnModel()
                .getColumn(0)
                .setMinWidth(0);

            table.getColumnModel()
                .getColumn(0)
                .setMaxWidth(0);

            table.getColumnModel()
                .getColumn(0)
                .setPreferredWidth(0);

            /*
             * VIEW BUTTON
             */

            table.getColumnModel()
                .getColumn(2)
                .setCellRenderer(
                    new ButtonRenderer()
                );

            table.getColumnModel()
                .getColumn(2)
                .setCellEditor(
                    new ButtonEditor(
                        new JCheckBox()
                    )
                );

            table.getColumnModel()
                .getColumn(1)
                .setPreferredWidth(450);

            table.getColumnModel()
                .getColumn(2)
                .setPreferredWidth(150);

            rs.close();
        }
        catch(Exception ex)
        {
            ex.printStackTrace();

            JOptionPane.showMessageDialog(
                this,
                "Error loading contacts:\n"
                + ex.getMessage()
            );
        }
    }

    /*
     * VIEW BUTTON DESIGN
     */

    class ButtonRenderer
        extends JButton
        implements TableCellRenderer
    {
        ButtonRenderer()
        {
            setOpaque(true);

            setFont(
                new Font(
                    "Arial",
                    Font.BOLD,
                    14
                )
            );
        }

        public Component
        getTableCellRendererComponent(
            JTable table,
            Object value,
            boolean isSelected,
            boolean hasFocus,
            int row,
            int column)
        {
            setText(
                "VIEW"
            );

            return this;
        }
    }

    /*
     * VIEW BUTTON CLICK
     */

    class ButtonEditor
        extends DefaultCellEditor
    {
        JButton button;

        int contactId;

        boolean clicked;

        ButtonEditor(JCheckBox checkBox)
        {
            super(checkBox);

            button = new JButton(
                "VIEW"
            );

            button.setOpaque(true);

            button.setFont(
                new Font(
                    "Arial",
                    Font.BOLD,
                    14
                )
            );

            button.addActionListener(
                new ActionListener()
                {
                    public void actionPerformed(
                        ActionEvent e)
                    {
                        fireEditingStopped();
                    }
                }
            );
        }

        public Component
        getTableCellEditorComponent(
            JTable table,
            Object value,
            boolean isSelected,
            int row,
            int column)
        {
            contactId =
                Integer.parseInt(
                    table.getValueAt(
                        row,
                        0
                    ).toString()
                );

            clicked = true;

            return button;
        }

        public Object getCellEditorValue()
        {
            if(clicked)
            {
                openContact(contactId);
            }

            clicked = false;

            return "VIEW";
        }
    }

    /*
     * OPEN CONTACT PROFILE
     */

    public void openContact(int contactId)
    {
        try
        {
            ConnectionClass obj =
                new ConnectionClass();

            String q =
                "select * from add_contact "
                + "where id="
                + contactId;

            ResultSet rs =
                obj.stm.executeQuery(q);

            if(rs.next())
            {
                String name =
                    rs.getString("name");

                String nickname =
                    rs.getString("nickname");

                String phone =
                    rs.getString("phone");

                String mobile =
                    rs.getString("mobile");

                String email =
                    rs.getString("email");

                String address =
                    rs.getString("address");

                String company =
                    rs.getString("company");

                String position =
                    rs.getString("position");

                String group =
                    rs.getString("group_name");

                String favorite =
                    rs.getString("favorite");

                ContactProfile cp =
                    new ContactProfile(
                        name,
                        nickname,
                        phone,
                        mobile,
                        email,
                        address,
                        company,
                        position,
                        group,
                        favorite
                    );

                cp.setVisible(true);

                /*
                 * CLOSE ALL CONTACTS
                 */

                this.dispose();
            }
            else
            {
                JOptionPane.showMessageDialog(
                    this,
                    "Contact not found."
                );
            }

            rs.close();
        }
        catch(Exception ex)
        {
            ex.printStackTrace();

            JOptionPane.showMessageDialog(
                this,
                "Error:\n"
                + ex.getMessage()
            );
        }
    }

    /*
     * BUTTON ACTIONS
     */

    public void actionPerformed(
        ActionEvent e)
    {
        if(e.getSource() == refresh)
        {
            showContacts();
        }

        if(e.getSource() == back)
        {
            this.dispose();

            new Dashboard().setVisible(true);
        }
    }

    public static void main(String args[])
    {
        new ViewContacts().setVisible(true);
    }
}