package PhoneBook;

import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class ContactStatistics extends JFrame implements ActionListener
{
    JLabel title;

    JLabel totalLabel;
    JLabel favoriteLabel;
    JLabel groupLabel;
    JLabel companyLabel;

    JLabel totalValue;
    JLabel favoriteValue;
    JLabel groupValue;
    JLabel companyValue;

    JButton refresh;
    JButton back;

    JTable table;
    JScrollPane sp;

    JPanel header;
    JPanel cards;
    JPanel tablePanel;
    JPanel bottom;

    Font titleFont;
    Font cardTitleFont;
    Font valueFont;
    Font buttonFont;

    ContactStatistics()
    {
        super("Contact Statistics");

        setSize(900, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout(10,10));

        // ================= FONTS =================

        titleFont = new Font("Arial", Font.BOLD, 28);
        cardTitleFont = new Font("Arial", Font.BOLD, 14);
        valueFont = new Font("Arial", Font.BOLD, 28);
        buttonFont = new Font("Arial", Font.BOLD, 15);

        // ================= HEADER =================

        header = new JPanel();
        header.setBackground(new Color(35,55,90));
        header.setPreferredSize(new Dimension(900,70));
        header.setLayout(new BorderLayout());

        title = new JLabel("  CONTACT STATISTICS");
        title.setForeground(Color.WHITE);
        title.setFont(titleFont);

        header.add(title, BorderLayout.WEST);

        add(header, BorderLayout.NORTH);

        // ================= CARDS =================

        cards = new JPanel();
        cards.setLayout(new GridLayout(1,4,15,10));
        cards.setBorder(
            BorderFactory.createEmptyBorder(
                15,15,10,15
            )
        );

        // ---------- CARD 1 ----------

        JPanel card1 = new JPanel();
        card1.setLayout(new BorderLayout());
        card1.setBackground(Color.WHITE);

        totalLabel = new JLabel(
            "TOTAL CONTACTS",
            JLabel.CENTER
        );

        totalLabel.setFont(cardTitleFont);

        totalValue = new JLabel(
            "0",
            JLabel.CENTER
        );

        totalValue.setFont(valueFont);

        card1.add(
            totalLabel,
            BorderLayout.NORTH
        );

        card1.add(
            totalValue,
            BorderLayout.CENTER
        );

        // ---------- CARD 2 ----------

        JPanel card2 = new JPanel();
        card2.setLayout(new BorderLayout());
        card2.setBackground(Color.WHITE);

        favoriteLabel = new JLabel(
            "FAVORITES",
            JLabel.CENTER
        );

        favoriteLabel.setFont(cardTitleFont);

        favoriteValue = new JLabel(
            "0",
            JLabel.CENTER
        );

        favoriteValue.setFont(valueFont);

        card2.add(
            favoriteLabel,
            BorderLayout.NORTH
        );

        card2.add(
            favoriteValue,
            BorderLayout.CENTER
        );

        // ---------- CARD 3 ----------

        JPanel card3 = new JPanel();
        card3.setLayout(new BorderLayout());
        card3.setBackground(Color.WHITE);

        groupLabel = new JLabel(
            "GROUPS",
            JLabel.CENTER
        );

        groupLabel.setFont(cardTitleFont);

        groupValue = new JLabel(
            "0",
            JLabel.CENTER
        );

        groupValue.setFont(valueFont);

        card3.add(
            groupLabel,
            BorderLayout.NORTH
        );

        card3.add(
            groupValue,
            BorderLayout.CENTER
        );

        // ---------- CARD 4 ----------

        JPanel card4 = new JPanel();
        card4.setLayout(new BorderLayout());
        card4.setBackground(Color.WHITE);

        companyLabel = new JLabel(
            "COMPANIES",
            JLabel.CENTER
        );

        companyLabel.setFont(cardTitleFont);

        companyValue = new JLabel(
            "0",
            JLabel.CENTER
        );

        companyValue.setFont(valueFont);

        card4.add(
            companyLabel,
            BorderLayout.NORTH
        );

        card4.add(
            companyValue,
            BorderLayout.CENTER
        );

        cards.add(card1);
        cards.add(card2);
        cards.add(card3);
        cards.add(card4);

        add(cards, BorderLayout.CENTER);

        // ================= TABLE =================

        table = new JTable();

        table.setRowHeight(28);
        table.setFont(
            new Font("Arial", Font.PLAIN, 14)
        );

        sp = new JScrollPane(table);

        tablePanel = new JPanel(
            new BorderLayout()
        );

        JLabel tableTitle = new JLabel(
            "  Statistics Stored in Database"
        );

        tableTitle.setFont(
            new Font("Arial", Font.BOLD, 18)
        );

        tablePanel.add(
            tableTitle,
            BorderLayout.NORTH
        );

        tablePanel.add(
            sp,
            BorderLayout.CENTER
        );

        // ================= BOTTOM =================

        bottom = new JPanel();

        refresh = new JButton("Refresh");
        back = new JButton("Back");

        refresh.setFont(buttonFont);
        back.setFont(buttonFont);

        refresh.addActionListener(this);
        back.addActionListener(this);

        bottom.add(refresh);
        bottom.add(back);

        // Create center panel
        JPanel centerPanel = new JPanel(
            new BorderLayout()
        );

        centerPanel.add(
            cards,
            BorderLayout.NORTH
        );

        centerPanel.add(
            tablePanel,
            BorderLayout.CENTER
        );

        add(
            centerPanel,
            BorderLayout.CENTER
        );

        add(
            bottom,
            BorderLayout.SOUTH
        );

        // ================= LOAD DATA =================

        updateStatistics();

        setVisible(true);
    }

    // ==================================================
    // UPDATE STATISTICS TABLE
    // ==================================================

    public void updateStatistics()
    {
        try
        {
            ConnectionClass obj =
                new ConnectionClass();

            // ==========================================
            // 1. TOTAL CONTACTS
            // ==========================================

            int totalContacts = 0;

            String q1 =
                "select count(*) from add_contact";

            ResultSet rs1 =
                obj.stm.executeQuery(q1);

            if(rs1.next())
            {
                totalContacts = rs1.getInt(1);
            }

            rs1.close();

            // ==========================================
            // 2. TOTAL FAVORITES
            // ==========================================

            int totalFavorites = 0;

            String q2 =
                "select count(*) from favorite_contact";

            ResultSet rs2 =
                obj.stm.executeQuery(q2);

            if(rs2.next())
            {
                totalFavorites = rs2.getInt(1);
            }

            rs2.close();

            // ==========================================
            // 3. TOTAL GROUPS
            // ==========================================

            int totalGroups = 0;

            String q3 =
                "select count(distinct group_name) "
                + "from add_contact "
                + "where group_name is not null "
                + "and group_name <> ''";

            ResultSet rs3 =
                obj.stm.executeQuery(q3);

            if(rs3.next())
            {
                totalGroups = rs3.getInt(1);
            }

            rs3.close();

            // ==========================================
            // 4. TOTAL COMPANIES
            // ==========================================

            int totalCompanies = 0;

            String q4 =
                "select count(distinct company) "
                + "from add_contact "
                + "where company is not null "
                + "and company <> ''";

            ResultSet rs4 =
                obj.stm.executeQuery(q4);

            if(rs4.next())
            {
                totalCompanies = rs4.getInt(1);
            }

            rs4.close();

            // ==========================================
            // UPDATE LABELS
            // ==========================================

            totalValue.setText(
                String.valueOf(totalContacts)
            );

            favoriteValue.setText(
                String.valueOf(totalFavorites)
            );

            groupValue.setText(
                String.valueOf(totalGroups)
            );

            companyValue.setText(
                String.valueOf(totalCompanies)
            );

            // ==========================================
            // UPDATE contact_statistics TABLE
            // ==========================================

            updateStatistic(
                obj,
                "Total Contacts",
                totalContacts
            );

            updateStatistic(
                obj,
                "Total Favorites",
                totalFavorites
            );

            updateStatistic(
                obj,
                "Total Groups",
                totalGroups
            );

            updateStatistic(
                obj,
                "Total Companies",
                totalCompanies
            );

            // ==========================================
            // LOAD TABLE
            // ==========================================

            loadStatisticsTable(obj);

        }
        catch(Exception ex)
        {
            ex.printStackTrace();

            JOptionPane.showMessageDialog(
                this,
                "Error updating statistics:\n"
                + ex.getMessage()
            );
        }
    }

    // ==================================================
    // INSERT OR UPDATE STATISTIC
    // ==================================================

    public void updateStatistic(
        ConnectionClass obj,
        String statisticName,
        int statisticValue
    )
    {
        try
        {
            // Check whether statistic already exists

            String check =
                "select * from contact_statistics "
                + "where statistic_name='"
                + statisticName + "'";

            ResultSet rs =
                obj.stm.executeQuery(check);

            if(rs.next())
            {
                // ==============================
                // UPDATE EXISTING RECORD
                // ==============================

                String update =
                    "update contact_statistics "
                    + "set statistic_value="
                    + statisticValue
                    + " where statistic_name='"
                    + statisticName + "'";

                obj.stm.executeUpdate(update);
            }
            else
            {
                // ==============================
                // INSERT NEW RECORD
                // ==============================

                String insert =
                    "insert into contact_statistics "
                    + "(statistic_name,statistic_value) "
                    + "values('"
                    + statisticName
                    + "',"
                    + statisticValue
                    + ")";

                obj.stm.executeUpdate(insert);
            }

            rs.close();
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
        }
    }

    // ==================================================
    // LOAD STATISTICS TABLE
    // ==================================================

    public void loadStatisticsTable(
        ConnectionClass obj
    )
    {
        try
        {
            String q =
                "select * from contact_statistics";

            ResultSet rs =
                obj.stm.executeQuery(q);

            DefaultTableModel model =
                new DefaultTableModel();

            model.addColumn("ID");
            model.addColumn("Statistic Name");
            model.addColumn("Value");

            while(rs.next())
            {
                model.addRow(
                    new Object[]
                    {
                        rs.getInt("id"),
                        rs.getString(
                            "statistic_name"
                        ),
                        rs.getInt(
                            "statistic_value"
                        )
                    }
                );
            }

            table.setModel(model);

            rs.close();
        }
        catch(Exception ex)
        {
            ex.printStackTrace();

            JOptionPane.showMessageDialog(
                this,
                "Error loading statistics table:\n"
                + ex.getMessage()
            );
        }
    }

    // ==================================================
    // BUTTON ACTIONS
    // ==================================================

    public void actionPerformed(ActionEvent e)
    {
        // ================= REFRESH =================

        if(e.getSource() == refresh)
        {
            updateStatistics();

            JOptionPane.showMessageDialog(
                this,
                "Statistics Updated Successfully!"
            );
        }

        // ================= BACK =================

        if(e.getSource() == back)
        {
            this.setVisible(false);

            new Dashboard().setVisible(true);
        }
    }

    // ==================================================
    // MAIN
    // ==================================================

    public static void main(String args[])
    {
        new ContactStatistics();
    }
}
