package PhoneBook;

import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import javax.swing.*;

public class Registration extends JFrame implements ActionListener
{
    JLabel l1,l2,l3,l4;
    JTextField tf1;
    JPasswordField pf1,pf2;
    JButton bt1,bt2;
    JPanel p1,p2;
    Font f,f1;

    Registration()
    {
        super("New User Registration");

        setLocation(450,150);
        setSize(450,350);

        f=new Font("Arial",Font.BOLD,25);
        f1=new Font("Arial",Font.BOLD,15);

        l1=new JLabel("New User Registration");
        l2=new JLabel("Username");
        l3=new JLabel("Password");
        l4=new JLabel("Confirm Password");

        tf1=new JTextField();
        pf1=new JPasswordField();
        pf2=new JPasswordField();

        bt1=new JButton("Register");
        bt2=new JButton("Back to Login");

        l1.setFont(f);

        l2.setFont(f1);
        l3.setFont(f1);
        l4.setFont(f1);

        tf1.setFont(f1);
        pf1.setFont(f1);
        pf2.setFont(f1);

        bt1.setFont(f1);
        bt2.setFont(f1);

        l1.setHorizontalAlignment(JLabel.CENTER);

        bt1.addActionListener(this);
        bt2.addActionListener(this);

        p1=new JPanel();
        p1.setLayout(new GridLayout(1,1,10,10));
        p1.add(l1);

        p2=new JPanel();
        p2.setLayout(new GridLayout(4,2,10,10));

        p2.add(l2);
        p2.add(tf1);

        p2.add(l3);
        p2.add(pf1);

        p2.add(l4);
        p2.add(pf2);

        p2.add(bt1);
        p2.add(bt2);

        setLayout(new BorderLayout(10,20));

        add(p1,"North");
        add(p2,"Center");

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    public void actionPerformed(ActionEvent e)
    {
        if(e.getSource()==bt1)
        {
            String username=tf1.getText();
            String password=new String(pf1.getPassword());
            String confirm=new String(pf2.getPassword());

            if(username.equals("") ||
               password.equals("") ||
               confirm.equals(""))
            {
                JOptionPane.showMessageDialog(
                    null,
                    "Please fill all the details."
                );

                return;
            }

            if(!password.equals(confirm))
            {
                JOptionPane.showMessageDialog(
                    null,
                    "Password and Confirm Password do not match."
                );

                return;
            }

            try
            {
                ConnectionClass obj=new ConnectionClass();

                String check =
                    "select * from login where username='"
                    + username + "'";

                ResultSet rs=obj.stm.executeQuery(check);

                if(rs.next())
                {
                    JOptionPane.showMessageDialog(
                        null,
                        "Username already exists."
                    );
                }
                else
                {
                    String q =
                        "insert into login "
                        + "(username,password) "
                        + "values('"
                        + username + "','"
                        + password + "')";

                    int aa=obj.stm.executeUpdate(q);

                    if(aa==1)
                    {
                        JOptionPane.showMessageDialog(
                            null,
                            "Registration successful."
                        );

                        this.setVisible(false);
                        new Login().setVisible(true);
                    }
                    else
                    {
                        JOptionPane.showMessageDialog(
                            null,
                            "Registration failed."
                        );
                    }
                }
            }
            catch(Exception ex)
            {
                ex.printStackTrace();

                JOptionPane.showMessageDialog(
                    null,
                    "Error: " + ex.getMessage()
                );
            }
        }

        if(e.getSource()==bt2)
        {
            this.setVisible(false);
            new Login().setVisible(true);
        }
    }

    public static void main(String[] args)
    {
        new Registration().setVisible(true);
    }
}
