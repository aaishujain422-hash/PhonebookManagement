package PhoneBook;

import java.awt.*;
import java.sql.*;
import java.awt.event.*;
import javax.swing.*;

public class EntryData extends JFrame implements ActionListener
{
    JLabel l1,l2,l3,l4,l5,l6,l7,l8,l9,l10,l11;

    JButton bt1,bt2;

    JPanel p1,p2;

    Font f,f1;

    JTextField tf1,tf2,tf3,tf4,tf5,tf6,tf7,tf8;

    JComboBox<String> groupCombo;

    JCheckBox cb1;

    EntryData()
    {
        super("Add Contact");

        setLocation(450,50);
        setSize(450,700);

        f=new Font(
            "Arial",
            Font.BOLD,
            25
        );

        f1=new Font(
            "Arial",
            Font.BOLD,
            15
        );

        // ================= LABELS =================

        l1=new JLabel("Add Contact");

        l2=new JLabel("Name");
        l3=new JLabel("Nick Name");
        l4=new JLabel("Phone No");
        l5=new JLabel("Mobile No");
        l6=new JLabel("Email Address");
        l7=new JLabel("Home Address");
        l8=new JLabel("Company");
        l9=new JLabel("Position");
        l10=new JLabel("Group Name");
        l11=new JLabel("Favorite");

        // ================= TEXT FIELDS =================

        tf1=new JTextField();
        tf2=new JTextField();
        tf3=new JTextField();
        tf4=new JTextField();
        tf5=new JTextField();
        tf6=new JTextField();
        tf7=new JTextField();
        tf8=new JTextField();

        // ================= GROUP DROPDOWN =================

        groupCombo=
            new JComboBox<String>();

        groupCombo.addItem("Select Group");

        loadGroups();

        // ================= FAVORITE =================

        cb1=
            new JCheckBox(
                "Add to Favorites"
            );

        // ================= BUTTONS =================

        bt1=
            new JButton(
                "Add Contact"
            );

        bt2=
            new JButton(
                "Back"
            );

        bt1.addActionListener(this);
        bt2.addActionListener(this);

        // ================= FONTS =================

        l1.setFont(f);

        l2.setFont(f1);
        l3.setFont(f1);
        l4.setFont(f1);
        l5.setFont(f1);
        l6.setFont(f1);
        l7.setFont(f1);
        l8.setFont(f1);
        l9.setFont(f1);
        l10.setFont(f1);
        l11.setFont(f1);

        tf1.setFont(f1);
        tf2.setFont(f1);
        tf3.setFont(f1);
        tf4.setFont(f1);
        tf5.setFont(f1);
        tf6.setFont(f1);
        tf7.setFont(f1);
        tf8.setFont(f1);

        groupCombo.setFont(f1);

        cb1.setFont(f1);

        bt1.setFont(f1);
        bt2.setFont(f1);

        // ================= PANEL 1 =================

        p1=new JPanel();

        p1.setLayout(
            new GridLayout(
                1,
                1,
                10,
                10
            )
        );

        p1.add(l1);

        // ================= PANEL 2 =================

        p2=new JPanel();

        p2.setLayout(
            new GridLayout(
                11,
                2,
                10,
                10
            )
        );

        p2.add(l2);
        p2.add(tf1);

        p2.add(l3);
        p2.add(tf2);

        p2.add(l4);
        p2.add(tf3);

        p2.add(l5);
        p2.add(tf4);

        p2.add(l6);
        p2.add(tf5);

        p2.add(l7);
        p2.add(tf6);

        p2.add(l8);
        p2.add(tf7);

        p2.add(l9);
        p2.add(tf8);

        p2.add(l10);
        p2.add(groupCombo);

        p2.add(l11);
        p2.add(cb1);

        p2.add(bt1);
        p2.add(bt2);

        // ================= LAYOUT =================

        setLayout(
            new BorderLayout(
                10,
                20
            )
        );

        add(
            p1,
            "North"
        );

        add(
            p2,
            "Center"
        );
    }

    // ==================================================
    // LOAD GROUPS
    // ==================================================

    public void loadGroups()
    {
        try
        {
            ConnectionClass obj=
                new ConnectionClass();

            String q=
                "select group_name "
                + "from contact_groups "
                + "order by group_name";

            ResultSet rs=
                obj.stm.executeQuery(q);

            while(rs.next())
            {
                groupCombo.addItem(
                    rs.getString("group_name")
                );
            }

            rs.close();
        }
        catch(Exception ex)
        {
            ex.printStackTrace();

            JOptionPane.showMessageDialog(
                this,
                "Error loading groups:\n"
                + ex.getMessage()
            );
        }
    }

    // ==================================================
    // GET GROUP ID
    // ==================================================

    public int getGroupId(String groupName)
    {
        int groupId=0;

        try
        {
            ConnectionClass obj=
                new ConnectionClass();

            String q=
                "select id "
                + "from contact_groups "
                + "where group_name='"
                + groupName
                + "'";

            ResultSet rs=
                obj.stm.executeQuery(q);

            if(rs.next())
            {
                groupId=
                    rs.getInt("id");
            }

            rs.close();
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
        }

        return groupId;
    }

    // ==================================================
    // BUTTON ACTION
    // ==================================================

    public void actionPerformed(ActionEvent e)
    {
        if(e.getSource()==bt1)
        {
            String name=
                tf1.getText();

            String nickname=
                tf2.getText();

            String phone=
                tf3.getText();

            String mobile=
                tf4.getText();

            String email=
                tf5.getText();

            String address=
                tf6.getText();

            String company=
                tf7.getText();

            String position=
                tf8.getText();

            String group=
                groupCombo
                .getSelectedItem()
                .toString();

            // ================= CHECK GROUP =================

            if(group.equals("Select Group"))
            {
                JOptionPane.showMessageDialog(
                    this,
                    "Please select a group."
                );

                return;
            }

            int groupId=
                getGroupId(group);

            if(groupId==0)
            {
                JOptionPane.showMessageDialog(
                    this,
                    "Selected group not found."
                );

                return;
            }

            // ================= FAVORITE =================

            String favorite;

            if(cb1.isSelected())
            {
                favorite="YES";
            }
            else
            {
                favorite="NO";
            }

            // ================= INSERT CONTACT =================

            try
            {
                ConnectionClass obj=
                    new ConnectionClass();

                String q=
                    "insert into add_contact "
                    + "(name,nickname,phone,mobile,email,"
                    + "address,company,position,group_name,"
                    + "group_id,favorite) "
                    + "values('"
                    + name
                    + "','"
                    + nickname
                    + "','"
                    + phone
                    + "','"
                    + mobile
                    + "','"
                    + email
                    + "','"
                    + address
                    + "','"
                    + company
                    + "','"
                    + position
                    + "','"
                    + group
                    + "',"
                    + groupId
                    + ",'"
                    + favorite
                    + "')";

                int aa=
                    obj.stm.executeUpdate(q);

                if(aa==1)
                {
                    // ================= ADD TO FAVORITES =================

                    if(cb1.isSelected())
                    {
                        String q2=
                            "insert into favorite_contact "
                            + "(name,nickname,phone,mobile,email,"
                            + "address,company,position,group_name) "
                            + "values('"
                            + name
                            + "','"
                            + nickname
                            + "','"
                            + phone
                            + "','"
                            + mobile
                            + "','"
                            + email
                            + "','"
                            + address
                            + "','"
                            + company
                            + "','"
                            + position
                            + "','"
                            + group
                            + "')";

                        obj.stm.executeUpdate(q2);
                    }

                    JOptionPane.showMessageDialog(
                        null,
                        "Your data inserted."
                    );

                    this.setVisible(false);

                    new Home().setVisible(true);
                }
                else
                {
                    JOptionPane.showMessageDialog(
                        null,
                        "Please fill the details carefully."
                    );
                }
            }
            catch(Exception ex)
            {
                ex.printStackTrace();

                JOptionPane.showMessageDialog(
                    null,
                    "Error: "
                    + ex.getMessage()
                );
            }
        }

        // ================= BACK =================

        if(e.getSource()==bt2)
        {
            this.setVisible(false);

            new Home().setVisible(true);
        }
    }

    // ==================================================
    // MAIN
    // ==================================================

    public static void main(String[] args)
    {
        new EntryData().setVisible(true);
    }
}