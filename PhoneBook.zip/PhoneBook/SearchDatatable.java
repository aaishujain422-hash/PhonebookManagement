package PhoneBook;

import java.awt.*;
import java.sql.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class SearchDatatable extends JFrame
{
    JTable t;
    Font f;

    SearchDatatable()
    {
        super("Contact Information");

        setLocation(1,1);
        setSize(900,400);

        f=new Font("Arial",Font.BOLD,15);

        // Empty table for default constructor
        t=new JTable();

        JScrollPane sp=new JScrollPane(t);

        add(sp);

        setVisible(true);
    }

    SearchDatatable(String name1)
    {
        super("Contact Information");

        setLocation(1,1);
        setSize(900,400);

        f=new Font("Arial",Font.BOLD,15);

        try
        {
            ConnectionClass obj=new ConnectionClass();

            String q=
                "select * from add_contact "
                + "where name='"+name1+"'";

            ResultSet rest=
                obj.stm.executeQuery(q);

            DefaultTableModel model=
                new DefaultTableModel();

            // ================= COLUMNS =================

            model.addColumn("ID");
            model.addColumn("Name");
            model.addColumn("Nick Name");
            model.addColumn("Phone");
            model.addColumn("Mobile");
            model.addColumn("Email");
            model.addColumn("Address");
            model.addColumn("Company");
            model.addColumn("Position");
            model.addColumn("Group Name");
            model.addColumn("Favorite");

            // ================= DATA =================

            while(rest.next())
            {
                model.addRow(
                    new Object[]
                    {
                        rest.getString("id"),
                        rest.getString("name"),
                        rest.getString("nickname"),
                        rest.getString("phone"),
                        rest.getString("mobile"),
                        rest.getString("email"),
                        rest.getString("address"),
                        rest.getString("company"),
                        rest.getString("position"),
                        rest.getString("group_name"),
                        rest.getString("favorite")
                    }
                );
            }

            t=new JTable(model);

            t.setFont(f);
            t.setRowHeight(25);

            JScrollPane sp=
                new JScrollPane(t);

            add(sp);

            rest.close();
        }
        catch(Exception ex)
        {
            ex.printStackTrace();

            JOptionPane.showMessageDialog(
                this,
                "Error loading contact:\n"
                + ex.getMessage()
            );
        }
    }

    public static void main(String[] args)
    {
        new SearchDatatable().setVisible(true);
    }
}
