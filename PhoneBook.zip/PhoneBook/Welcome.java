package PhoneBook;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Welcome extends JFrame implements ActionListener
{
    JLabel title,subtitle,welcome,description,footer;
    JButton login,register;
    JPanel mainPanel,leftPanel,rightPanel,buttonPanel,headerPanel;
    Font titleFont,subtitleFont,headingFont,textFont,buttonFont,footerFont;

    Welcome()
    {
        super("Phone Book Management System");

        setSize(850,500);
        setLocationRelativeTo(null);

        titleFont=new Font("Arial",Font.BOLD,32);
        subtitleFont=new Font("Arial",Font.PLAIN,16);
        headingFont=new Font("Arial",Font.BOLD,25);
        textFont=new Font("Arial",Font.PLAIN,16);
        buttonFont=new Font("Arial",Font.BOLD,16);
        footerFont=new Font("Arial",Font.PLAIN,12);

        /* ---------------- HEADER ---------------- */

        headerPanel=new JPanel();
        headerPanel.setBackground(new Color(35,55,90));
        headerPanel.setLayout(new GridLayout(2,1));

        title=new JLabel("PHONE BOOK");
        title.setForeground(Color.WHITE);
        title.setFont(titleFont);
        title.setHorizontalAlignment(JLabel.CENTER);

        subtitle=new JLabel("Management System");
        subtitle.setForeground(new Color(220,225,235));
        subtitle.setFont(subtitleFont);
        subtitle.setHorizontalAlignment(JLabel.CENTER);

        headerPanel.add(title);
        headerPanel.add(subtitle);

        /* ---------------- MAIN PANEL ---------------- */

        mainPanel=new JPanel();
        mainPanel.setLayout(new GridLayout(1,2));
        mainPanel.setBackground(new Color(245,247,250));

        /* ---------------- LEFT PANEL ---------------- */

        leftPanel=new JPanel();
        leftPanel.setBackground(new Color(245,247,250));
        leftPanel.setLayout(new GridLayout(4,1,10,10));

        welcome=new JLabel("Welcome!");
        welcome.setFont(headingFont);
        welcome.setForeground(new Color(35,55,90));
        welcome.setHorizontalAlignment(JLabel.CENTER);

        description=new JLabel(
            "<html><center>"
            + "Manage your contacts easily and efficiently.<br><br>"
            + "Add, search, edit, delete and organize<br>"
            + "your contacts in one place."
            + "</center></html>"
        );

        description.setFont(textFont);
        description.setForeground(new Color(80,80,80));
        description.setHorizontalAlignment(JLabel.CENTER);

        leftPanel.add(new JLabel(""));
        leftPanel.add(welcome);
        leftPanel.add(description);
        leftPanel.add(new JLabel(""));

        /* ---------------- RIGHT PANEL ---------------- */

        rightPanel=new JPanel();
        rightPanel.setBackground(Color.WHITE);
        rightPanel.setBorder(
            BorderFactory.createEmptyBorder(50,50,50,50)
        );

        rightPanel.setLayout(new GridLayout(3,1,15,15));

        JLabel account=new JLabel("Get Started");
        account.setFont(headingFont);
        account.setForeground(new Color(35,55,90));
        account.setHorizontalAlignment(JLabel.CENTER);

        login=new JButton("LOGIN");
        register=new JButton("NEW USER REGISTRATION");

        login.setFont(buttonFont);
        register.setFont(buttonFont);

        login.setForeground(Color.WHITE);
        register.setForeground(Color.WHITE);

        login.setBackground(new Color(35,55,90));
        register.setBackground(new Color(70,110,150));

        login.setFocusPainted(false);
        register.setFocusPainted(false);

        login.setBorder(
            BorderFactory.createEmptyBorder(12,20,12,20)
        );

        register.setBorder(
            BorderFactory.createEmptyBorder(12,20,12,20)
        );

        login.addActionListener(this);
        register.addActionListener(this);

        rightPanel.add(account);
        rightPanel.add(login);
        rightPanel.add(register);

        mainPanel.add(leftPanel);
        mainPanel.add(rightPanel);

        /* ---------------- FOOTER ---------------- */

        footer=new JLabel(
            "Phone Book Management System  |  Welcome"
        );

        footer.setFont(footerFont);
        footer.setForeground(Color.GRAY);
        footer.setHorizontalAlignment(JLabel.CENTER);

        /* ---------------- FRAME ---------------- */

        setLayout(new BorderLayout());

        add(headerPanel,"North");
        add(mainPanel,"Center");
        add(footer,"South");

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    public void actionPerformed(ActionEvent e)
    {
        if(e.getSource()==login)
        {
            this.setVisible(false);
            new Login().setVisible(true);
        }

        if(e.getSource()==register)
        {
            this.setVisible(false);
            new Registration().setVisible(true);
        }
    }

    public static void main(String[] args)
    {
        new Welcome().setVisible(true);
    }
}