package PhoneBook;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class ContactProfile extends JFrame
    implements ActionListener
{
    JLabel title;
    JLabel avatar;
    JLabel nameLabel;
    JLabel favoriteLabel;

    JLabel l1,l2,l3,l4,l5,l6,l7,l8,l9;
    JLabel v1,v2,v3,v4,v5,v6,v7,v8,v9;

    JButton bt1;

    JPanel header;
    JPanel profilePanel;
    JPanel detailsPanel;
    JPanel bottomPanel;

    Font titleFont;
    Font nameFont;
    Font labelFont;
    Font valueFont;
    Font buttonFont;

    ContactProfile(
        String name,
        String nickname,
        String phone,
        String mobile,
        String email,
        String address,
        String company,
        String position,
        String group,
        String favorite)
    {
        super("Contact Profile");

        setSize(650,700);

        setLocationRelativeTo(null);

        setDefaultCloseOperation(
            JFrame.DISPOSE_ON_CLOSE
        );

        titleFont =
            new Font(
                "Arial",
                Font.BOLD,
                22
            );

        nameFont =
            new Font(
                "Arial",
                Font.BOLD,
                25
            );

        labelFont =
            new Font(
                "Arial",
                Font.BOLD,
                14
            );

        valueFont =
            new Font(
                "Arial",
                Font.PLAIN,
                15
            );

        buttonFont =
            new Font(
                "Arial",
                Font.BOLD,
                14
            );

        /*
         * HEADER
         */

        header = new JPanel();

        header.setBackground(
            new Color(35,55,90)
        );

        header.setLayout(
            new BorderLayout()
        );

        title = new JLabel(
            "CONTACT PROFILE"
        );

        title.setFont(titleFont);

        title.setForeground(
            Color.WHITE
        );

        title.setHorizontalAlignment(
            JLabel.CENTER
        );

        header.add(
            title,
            BorderLayout.CENTER
        );

        /*
         * PROFILE SECTION
         */

        profilePanel = new JPanel();

        profilePanel.setBackground(
            new Color(245,247,250)
        );

        profilePanel.setLayout(
            new FlowLayout(
                FlowLayout.CENTER,
                20,
                20
            )
        );

        /*
         * CONTACT AVATAR
         */

        String firstLetter = "?";

        if(
            name != null &&
            name.length() > 0
        )
        {
            firstLetter =
                name.substring(0,1)
                .toUpperCase();
        }

        avatar = new JLabel(
            firstLetter,
            JLabel.CENTER
        );

        avatar.setFont(
            new Font(
                "Arial",
                Font.BOLD,
                35
            )
        );

        avatar.setForeground(
            Color.WHITE
        );

        avatar.setOpaque(true);

        avatar.setBackground(
            new Color(70,110,150)
        );

        avatar.setPreferredSize(
            new Dimension(80,80)
        );

        profilePanel.add(
            avatar
        );

        /*
         * NAME SECTION
         */

        JPanel namePanel =
            new JPanel();

        namePanel.setOpaque(false);

        namePanel.setLayout(
            new GridLayout(
                2,
                1,
                5,
                5
            )
        );

        nameLabel =
            new JLabel(name);

        nameLabel.setFont(
            nameFont
        );

        nameLabel.setForeground(
            new Color(35,55,90)
        );

        favoriteLabel =
            new JLabel();

        favoriteLabel.setFont(
            new Font(
                "Arial",
                Font.BOLD,
                14
            )
        );

        if(
            favorite != null &&
            favorite.equalsIgnoreCase("YES")
        )
        {
            favoriteLabel.setText(
                "★ Favorite Contact"
            );

            favoriteLabel.setForeground(
                new Color(220,150,20)
            );
        }
        else
        {
            favoriteLabel.setText(
                "☆ Regular Contact"
            );

            favoriteLabel.setForeground(
                Color.GRAY
            );
        }

        namePanel.add(
            nameLabel
        );

        namePanel.add(
            favoriteLabel
        );

        profilePanel.add(
            namePanel
        );

        /*
         * DETAILS PANEL
         */

        detailsPanel = new JPanel();

        detailsPanel.setBackground(
            Color.WHITE
        );

        detailsPanel.setBorder(
            BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(
                    new Color(220,220,220)
                ),
                BorderFactory.createEmptyBorder(
                    20,
                    25,
                    20,
                    25
                )
            )
        );

        detailsPanel.setLayout(
            new GridLayout(
                9,
                2,
                15,
                15
            )
        );

        /*
         * LABELS
         */

        l1 = new JLabel("Nickname");
        l2 = new JLabel("Phone");
        l3 = new JLabel("Mobile");
        l4 = new JLabel("Email");
        l5 = new JLabel("Address");
        l6 = new JLabel("Company");
        l7 = new JLabel("Position");
        l8 = new JLabel("Group");
        l9 = new JLabel("Favorite");

        /*
         * VALUES
         */

        v1 = new JLabel(nickname);
        v2 = new JLabel(phone);
        v3 = new JLabel(mobile);
        v4 = new JLabel(email);
        v5 = new JLabel(address);
        v6 = new JLabel(company);
        v7 = new JLabel(position);
        v8 = new JLabel(group);
        v9 = new JLabel(favorite);

        /*
         * LABEL FONTS
         */

        l1.setFont(labelFont);
        l2.setFont(labelFont);
        l3.setFont(labelFont);
        l4.setFont(labelFont);
        l5.setFont(labelFont);
        l6.setFont(labelFont);
        l7.setFont(labelFont);
        l8.setFont(labelFont);
        l9.setFont(labelFont);

        /*
         * VALUE FONTS
         */

        v1.setFont(valueFont);
        v2.setFont(valueFont);
        v3.setFont(valueFont);
        v4.setFont(valueFont);
        v5.setFont(valueFont);
        v6.setFont(valueFont);
        v7.setFont(valueFont);
        v8.setFont(valueFont);
        v9.setFont(valueFont);

        /*
         * LABEL COLORS
         */

        l1.setForeground(
            new Color(70,70,70)
        );

        l2.setForeground(
            new Color(70,70,70)
        );

        l3.setForeground(
            new Color(70,70,70)
        );

        l4.setForeground(
            new Color(70,70,70)
        );

        l5.setForeground(
            new Color(70,70,70)
        );

        l6.setForeground(
            new Color(70,70,70)
        );

        l7.setForeground(
            new Color(70,70,70)
        );

        l8.setForeground(
            new Color(70,70,70)
        );

        l9.setForeground(
            new Color(70,70,70)
        );

        /*
         * ADD DETAILS
         */

        detailsPanel.add(l1);
        detailsPanel.add(v1);

        detailsPanel.add(l2);
        detailsPanel.add(v2);

        detailsPanel.add(l3);
        detailsPanel.add(v3);

        detailsPanel.add(l4);
        detailsPanel.add(v4);

        detailsPanel.add(l5);
        detailsPanel.add(v5);

        detailsPanel.add(l6);
        detailsPanel.add(v6);

        detailsPanel.add(l7);
        detailsPanel.add(v7);

        detailsPanel.add(l8);
        detailsPanel.add(v8);

        detailsPanel.add(l9);
        detailsPanel.add(v9);

        /*
         * BACK BUTTON
         */

        bt1 = new JButton(
            "←  Back to Contacts"
        );

        bt1.setFont(
            buttonFont
        );

        bt1.setForeground(
            Color.WHITE
        );

        bt1.setBackground(
            new Color(35,55,90)
        );

        bt1.setFocusPainted(false);

        bt1.setBorder(
            BorderFactory.createEmptyBorder(
                10,
                25,
                10,
                25
            )
        );

        bt1.addActionListener(this);

        bottomPanel = new JPanel();

        bottomPanel.setBackground(
            new Color(245,247,250)
        );

        bottomPanel.setBorder(
            BorderFactory.createEmptyBorder(
                10,
                10,
                15,
                10
            )
        );

        bottomPanel.add(bt1);

        /*
         * MAIN LAYOUT
         */

        setLayout(
            new BorderLayout(
                10,
                10
            )
        );

        add(
            header,
            BorderLayout.NORTH
        );

        JPanel centerPanel =
            new JPanel();

        centerPanel.setBackground(
            new Color(245,247,250)
        );

        centerPanel.setLayout(
            new BorderLayout(
                10,
                10
            )
        );

        centerPanel.add(
            profilePanel,
            BorderLayout.NORTH
        );

        centerPanel.add(
            detailsPanel,
            BorderLayout.CENTER
        );

        add(
            centerPanel,
            BorderLayout.CENTER
        );

        add(
            bottomPanel,
            BorderLayout.SOUTH
        );
    }

    /*
     * BACK TO ALL CONTACTS
     */

    public void actionPerformed(
        ActionEvent e)
    {
        if(e.getSource() == bt1)
        {
            /*
             * CLOSE PROFILE
             */

            this.setVisible(false);

            /*
             * OPEN ALL CONTACTS AGAIN
             */

            new ViewContacts().setVisible(true);
        }
    }

    public static void main(
        String args[])
    {
        new ContactProfile(
            "Rahul",
            "Rocky",
            "1234567890",
            "9876543210",
            "rahul@gmail.com",
            "Mumbai",
            "ABC Ltd",
            "Manager",
            "Work",
            "YES"
        ).setVisible(true);
    }
}
    